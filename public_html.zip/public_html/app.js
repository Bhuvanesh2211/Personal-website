window.addEventListener('load', function(){
    let preloaders = document.querySelectorAll('.preloader');
    if(preloaders)
    {
        preloaders.forEach(preloader=>{
            preloader.classList.add('active');
            preloader.addEventListener('transitionend', ()=>{
                preloader.style.display = 'none';
            });
        });
    }
});